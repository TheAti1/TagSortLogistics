package com.tagsortlogistics.mixin.client;

import com.tagsortlogistics.networking.ModPayloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_476;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public abstract class GenericContainerScreenMixin extends class_437 {

    @Shadow protected int leftPos;
    @Shadow protected int imageWidth;
    @Shadow protected int topPos;

    protected GenericContainerScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void tagsortlogistics$onInit(CallbackInfo ci) {
        if (!((Object) this instanceof class_476)) return;

        int startX = this.leftPos + this.imageWidth;
        int startY = this.topPos;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Pull"), button -> {
            ClientPlayNetworking.send(new ModPayloads.PullMatchingPayload());
        }).method_46434(startX, startY, 40, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("A-Z"), button -> {
            ClientPlayNetworking.send(new ModPayloads.SortInventoryPayload());
        }).method_46434(startX, startY + 22, 40, 20).method_46431());
    }
}
