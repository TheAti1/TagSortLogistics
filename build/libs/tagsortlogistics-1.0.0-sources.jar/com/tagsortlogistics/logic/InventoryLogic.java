package com.tagsortlogistics.logic;

import com.tagsortlogistics.networking.ModPayloads.*;
import com.tagsortlogistics.util.TagHelper;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1263;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InventoryLogic {
    public static void init() {
        ServerPlayNetworking.registerGlobalReceiver(PullMatchingPayload.TYPE, (payload, context) -> {
            context.server().execute(() -> {
                handlePullMatching(context.player());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SortInventoryPayload.TYPE, (payload, context) -> {
            context.server().execute(() -> {
                handleSortInventory(context.player());
            });
        });
    }

    private static void handlePullMatching(class_3222 player) {
        class_1703 handler = player.field_7512;
        if (handler instanceof class_1707 chestMenu) {
            class_1263 chestInv = chestMenu.method_7629();
            class_1937 world = player.method_37908();
            class_2338 chestPos = LastOpenedTracker.lastOpenedPos.get(player.method_5667());

            if (chestPos != null && chestInv != null) {
                class_1661 playerInv = player.method_31548();
                for (int i = 0; i < playerInv.field_7547.size(); i++) {
                    class_1799 playerStack = playerInv.field_7547.get(i);
                    if (!playerStack.method_7960() && TagHelper.doesItemMatchChestTags(world, chestPos, playerStack)) {
                        class_1799 remaining = transferStack(playerStack, chestInv);
                        playerInv.field_7547.set(i, remaining);
                    }
                }
            }
        }
    }

    private static void handleSortInventory(class_3222 player) {
        class_1703 handler = player.field_7512;
        if (handler instanceof class_1707 chestMenu) {
            class_1263 chestInv = chestMenu.method_7629();
            sortInventory(chestInv);
        }
    }

    private static void sortInventory(class_1263 inv) {
        List<class_1799> items = new ArrayList<>();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960()) {
                items.add(stack.method_7972());
                inv.method_5447(i, class_1799.field_8037);
            }
        }

        // Stack items together
        List<class_1799> stacked = new ArrayList<>();
        for (class_1799 item : items) {
            for (class_1799 existing : stacked) {
                if (class_1799.method_31577(item, existing)) {
                    int space = existing.method_7914() - existing.method_7947();
                    if (space > 0) {
                        int toAdd = Math.min(space, item.method_7947());
                        existing.method_7933(toAdd);
                        item.method_7934(toAdd);
                        if (item.method_7960()) break;
                    }
                }
            }
            if (!item.method_7960()) {
                stacked.add(item);
            }
        }

        stacked.sort(Comparator.comparing(stack -> stack.method_7964().getString()));

        for (int i = 0; i < stacked.size() && i < inv.method_5439(); i++) {
            inv.method_5447(i, stacked.get(i));
        }
    }

    private static class_1799 transferStack(class_1799 stack, class_1263 dest) {
        class_1799 remaining = stack.method_7972();
        for (int i = 0; i < dest.method_5439(); i++) {
            class_1799 destStack = dest.method_5438(i);
            if (!destStack.method_7960() && class_1799.method_31577(remaining, destStack)) {
                int space = destStack.method_7914() - destStack.method_7947();
                if (space > 0) {
                    int toAdd = Math.min(space, remaining.method_7947());
                    destStack.method_7933(toAdd);
                    remaining.method_7934(toAdd);
                    if (remaining.method_7960()) return class_1799.field_8037;
                }
            }
        }
        for (int i = 0; i < dest.method_5439(); i++) {
            if (dest.method_5438(i).method_7960()) {
                dest.method_5447(i, remaining.method_7972());
                return class_1799.field_8037;
            }
        }
        return remaining;
    }
}
