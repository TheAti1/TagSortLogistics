package com.tagsortlogistics.logic;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2338;

public class LastOpenedTracker {
    public static final Map<UUID, class_2338> lastOpenedPos = new HashMap<>();
}
