package com.tagsortlogistics;

import com.tagsortlogistics.logic.InventoryLogic;
import com.tagsortlogistics.logic.LastOpenedTracker;
import com.tagsortlogistics.networking.ModPayloads;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_1263;
import net.minecraft.class_1269;
import net.minecraft.class_2586;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TagSortLogistics implements ModInitializer {
	public static final String MOD_ID = "tagsortlogistics";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.playC2S().register(ModPayloads.PullMatchingPayload.TYPE, ModPayloads.PullMatchingPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ModPayloads.SortInventoryPayload.TYPE, ModPayloads.SortInventoryPayload.CODEC);

		InventoryLogic.init();

		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
			if (!world.method_8608()) {
				class_2586 be = world.method_8321(hitResult.method_17777());
				if (be instanceof class_1263) {
					LastOpenedTracker.lastOpenedPos.put(player.method_5667(), hitResult.method_17777().method_10062());
				}
			}
			return class_1269.field_5811;
		});

		LOGGER.info("TagSort Logistics initialized!");
	}
}
