package com.tagsortlogistics.networking;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class ModPayloads {
    public record PullMatchingPayload() implements class_8710 {
        public static final class_9154<PullMatchingPayload> TYPE = new class_9154<>(class_2960.method_60655("tagsortlogistics", "pull_matching"));
        public static final class_9139<class_9129, PullMatchingPayload> CODEC = class_9139.method_56431(new PullMatchingPayload());
        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    public record SortInventoryPayload() implements class_8710 {
        public static final class_9154<SortInventoryPayload> TYPE = new class_9154<>(class_2960.method_60655("tagsortlogistics", "sort_inventory"));
        public static final class_9139<class_9129, SortInventoryPayload> CODEC = class_9139.method_56431(new SortInventoryPayload());
        @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }
}
