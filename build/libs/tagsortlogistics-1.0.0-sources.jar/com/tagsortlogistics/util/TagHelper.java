package com.tagsortlogistics.util;

import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1533;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_6862;

public class TagHelper {

    /**
     * Finds item frames attached to or near a specific block position (like a chest).
     */
    public static List<class_1533> getAttachedItemFrames(class_1937 world, class_2338 pos) {
        class_238 searchBox = new class_238(pos).method_1014(1.0);
        return world.method_8390(class_1533.class, searchBox, entity -> true);
    }

    /**
     * Gets all item tags associated with the items in the item frames around a chest.
     */
    public static List<class_6862<class_1792>> getTagsFromFrames(class_1937 world, class_2338 pos) {
        return getAttachedItemFrames(world, pos).stream()
                .map(class_1533::method_6940)
                .filter(stack -> !stack.method_7960())
                .flatMap(stack -> stack.method_40133())
                .distinct()
                .collect(Collectors.toList());
    }

    /**
     * Checks if a given ItemStack matches any of the tags found in the item frames around the chest.
     */
    public static boolean doesItemMatchChestTags(class_1937 world, class_2338 chestPos, class_1799 stackToCheck) {
        if (stackToCheck.method_7960()) return false;

        List<class_6862<class_1792>> chestTags = getTagsFromFrames(world, chestPos);

        if (chestTags.isEmpty()) return false;

        for (class_6862<class_1792> tag : chestTags) {
            if (stackToCheck.method_31573(tag)) {
                return true;
            }
        }
        return false;
    }
}
